﻿// (C) Copyright 2023 by  
//
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using System;

// This line is not mandatory, but improves loading performances
[assembly: CommandClass(typeof(AutoCAD_CSharp_plug_in2.MyCommands))]

namespace AutoCAD_CSharp_plug_in2
{
    public class MyCommands
    {
        private static KeepStraightOverrule myOverrule;
        const string mXdataName = "ADSK_ATTRIBUTE_ZERO_OVERRULE";

        [CommandMethod("DontKeepStraight")]
        public static void RemoveXdata()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            PromptEntityOptions opts = new PromptEntityOptions("\nSelect a block reference:");
            opts.SetRejectMessage("\nMust be block reference...");
            opts.AddAllowedClass(typeof(BlockReference), true);
            PromptEntityResult res = ed.GetEntity(opts);

            if (res.Status != PromptStatus.OK)
            {
                return;
            }

            Database db = doc.Database;
            AddRegAppId(db);
            using (Transaction trans = db.TransactionManager.StartTransaction())
            {
                BlockReference blkRef = trans.GetObject(res.ObjectId, OpenMode.ForRead) as BlockReference;
                AttributeCollection attRefColl = blkRef.AttributeCollection;
                foreach (ObjectId objId in attRefColl)
                {
                    AttributeReference attRef = trans.GetObject(objId, OpenMode.ForWrite) as AttributeReference;
                    using (ResultBuffer resBuf = new ResultBuffer(new TypedValue((int)DxfCode.ExtendedDataRegAppName, mXdataName)))
                    {
                        attRef.XData = resBuf;
                    }
                }
                trans.Commit();
            }
        }

        [CommandMethod("keepstraight")]
        public static void ImplementOverrule()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Editor ed = doc.Editor;
            PromptEntityOptions opts = new PromptEntityOptions("\nSelect a block reference:");
            opts.SetRejectMessage("\nMust be block reference...");
            opts.AddAllowedClass(typeof(BlockReference), true);
            PromptEntityResult res = ed.GetEntity(opts);

            if (res.Status != PromptStatus.OK)
            {
                return;
            }

            ObjectId[] objIds;
            Database db = doc.Database;
            AddRegAppId(db);

            using (Transaction trans = db.TransactionManager.StartTransaction())
            {
                BlockReference blkRef = (BlockReference)trans.GetObject(res.ObjectId, OpenMode.ForRead);
                AttributeCollection attRefColl = blkRef.AttributeCollection;
                foreach (ObjectId objId in attRefColl)
                {
                    AttributeReference attRef = trans.GetObject(objId, OpenMode.ForWrite) as AttributeReference;
                    using (ResultBuffer resBuf = new ResultBuffer(new TypedValue((int)DxfCode.ExtendedDataRegAppName, mXdataName)))
                    {
                        attRef.XData = resBuf;
                    } 
                }
            }

            if (myOverrule == null)
            {
                myOverrule = new KeepStraightOverrule();
                Overrule.AddOverrule(RXClass.GetClass(typeof(AttributeReference)), myOverrule, false);
            }

            Overrule.Overruling = true;
        }

        [CommandMethod("ActivateOverrule")]
        public static void ActivateOverrule()
        {
            if (myOverrule == null)
            {
                myOverrule = new KeepStraightOverrule();
                Overrule.AddOverrule(RXClass.GetClass(typeof(AttributeReference)), myOverrule, false);
            }
            myOverrule.SetXDataFilter(mXdataName);
            Overrule.Overruling = true;
        }

        private static void AddRegAppId(Database db)
        {
            using (Transaction trans = db.TransactionManager.StartTransaction())
            {
                RegAppTable appTbl = trans.GetObject(db.RegAppTableId, OpenMode.ForRead) as RegAppTable;
                if (!appTbl.Has(mXdataName))
                {
                    RegAppTableRecord appTblRec = new RegAppTableRecord();
                    appTbl.UpgradeOpen();
                    appTblRec.Name = mXdataName;
                    appTbl.Add(appTblRec);
                    trans.AddNewlyCreatedDBObject(appTblRec, true);
                }
                trans.Commit();
            }
        }

        public class KeepStraightOverrule : TransformOverrule 
        {
            public void TransformBy(Entity entity, Matrix3d transform)
            {
                base.TransformBy(entity, transform);
                AttributeReference attRef = entity as AttributeReference;
                attRef.Rotation = 0.0;
            }
        }  
    }

}
